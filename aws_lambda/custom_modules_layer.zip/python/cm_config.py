config = {'refresh_token' : 'NoGJWr2wTUbY4NGl3YLVMcH7fF1BKxdzPH1K9UHFTfWAa5GN9Ol8M48XLNsAk7ER',
'consumer_key': 'xMJuhJlndH1Y89eXX1vY8S0uO',
'consumer_secret_key': 'USIPZc4VJV8RDjsXkNo9PpIrdGKyHFTyK8tBnwl8o0QgkFMvJB', 
'access_token': '63628835-MEG8Sfprjp3DJeXLjJ7vZEGrEJaOqZm30mpZPdAAf', 
'access_token_secret': '9SuGHDMmKUykKBadjLtDrO3hRPt2m1j2jOJFgBUfn48q4',
'iframe_key':'28469d6d1a6131e55e4423', #api access to iframely --> https://iframely.com/
'client_id': 'fde423d9c3454b2b87726f5afab15cb4', #spotify client id
'client_secret_id': '9a5747edc5c043c8bed9c8ba3b04c6bf' #spotify secret client id



}